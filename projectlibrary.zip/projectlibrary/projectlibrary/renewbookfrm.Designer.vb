﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class renewbookfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.backbtn = New System.Windows.Forms.Button()
        Me.refreshbtn = New System.Windows.Forms.Button()
        Me.renewdate = New System.Windows.Forms.DateTimePicker()
        Me.searchbtn = New System.Windows.Forms.Button()
        Me.detailpanel = New System.Windows.Forms.Panel()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.returndate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.issuedate = New System.Windows.Forms.DateTimePicker()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.renewbtn = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.detailpanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.DarkCyan
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(106, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(162, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "RENEW BOOK "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(180, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(187, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "BOOK Accession No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label3.Location = New System.Drawing.Point(180, 142)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(222, 24)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Enter New Deadline Date"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(421, 100)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(230, 20)
        Me.TextBox2.TabIndex = 4
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel1.Controls.Add(Me.backbtn)
        Me.Panel1.Controls.Add(Me.refreshbtn)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(-2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(953, 74)
        Me.Panel1.TabIndex = 5
        '
        'backbtn
        '
        Me.backbtn.BackColor = System.Drawing.Color.DarkSlateGray
        Me.backbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbtn.ForeColor = System.Drawing.Color.White
        Me.backbtn.Location = New System.Drawing.Point(800, 24)
        Me.backbtn.Name = "backbtn"
        Me.backbtn.Size = New System.Drawing.Size(79, 27)
        Me.backbtn.TabIndex = 9
        Me.backbtn.Text = "Back"
        Me.backbtn.UseVisualStyleBackColor = False
        '
        'refreshbtn
        '
        Me.refreshbtn.BackColor = System.Drawing.Color.DarkSlateGray
        Me.refreshbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.refreshbtn.ForeColor = System.Drawing.Color.White
        Me.refreshbtn.Location = New System.Drawing.Point(698, 24)
        Me.refreshbtn.Name = "refreshbtn"
        Me.refreshbtn.Size = New System.Drawing.Size(79, 27)
        Me.refreshbtn.TabIndex = 8
        Me.refreshbtn.Text = "Refresh"
        Me.refreshbtn.UseVisualStyleBackColor = False
        '
        'renewdate
        '
        Me.renewdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.renewdate.Location = New System.Drawing.Point(421, 146)
        Me.renewdate.Name = "renewdate"
        Me.renewdate.Size = New System.Drawing.Size(230, 20)
        Me.renewdate.TabIndex = 6
        '
        'searchbtn
        '
        Me.searchbtn.BackColor = System.Drawing.Color.DarkSlateGray
        Me.searchbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchbtn.ForeColor = System.Drawing.Color.White
        Me.searchbtn.Location = New System.Drawing.Point(657, 97)
        Me.searchbtn.Name = "searchbtn"
        Me.searchbtn.Size = New System.Drawing.Size(109, 27)
        Me.searchbtn.TabIndex = 7
        Me.searchbtn.Text = "Search"
        Me.searchbtn.UseVisualStyleBackColor = False
        '
        'detailpanel
        '
        Me.detailpanel.BackColor = System.Drawing.Color.DarkSlateGray
        Me.detailpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.detailpanel.Controls.Add(Me.TextBox5)
        Me.detailpanel.Controls.Add(Me.Label13)
        Me.detailpanel.Controls.Add(Me.returndate)
        Me.detailpanel.Controls.Add(Me.Label4)
        Me.detailpanel.Controls.Add(Me.issuedate)
        Me.detailpanel.Controls.Add(Me.TextBox4)
        Me.detailpanel.Controls.Add(Me.TextBox3)
        Me.detailpanel.Controls.Add(Me.TextBox1)
        Me.detailpanel.Controls.Add(Me.Label7)
        Me.detailpanel.Controls.Add(Me.Label9)
        Me.detailpanel.Controls.Add(Me.Label10)
        Me.detailpanel.Controls.Add(Me.Label11)
        Me.detailpanel.Controls.Add(Me.Label12)
        Me.detailpanel.Location = New System.Drawing.Point(42, 226)
        Me.detailpanel.Name = "detailpanel"
        Me.detailpanel.Size = New System.Drawing.Size(848, 205)
        Me.detailpanel.TabIndex = 9
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(585, 51)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(211, 20)
        Me.TextBox5.TabIndex = 27
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.DarkCyan
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(163, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(507, 25)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = "Book  Details"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'returndate
        '
        Me.returndate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.returndate.Location = New System.Drawing.Point(586, 139)
        Me.returndate.Name = "returndate"
        Me.returndate.Size = New System.Drawing.Size(210, 20)
        Me.returndate.TabIndex = 25
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label4.Location = New System.Drawing.Point(436, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 21)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Return Date"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'issuedate
        '
        Me.issuedate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.issuedate.Location = New System.Drawing.Point(587, 98)
        Me.issuedate.Name = "issuedate"
        Me.issuedate.Size = New System.Drawing.Size(210, 20)
        Me.issuedate.TabIndex = 14
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(180, 147)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(211, 20)
        Me.TextBox4.TabIndex = 11
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(180, 103)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(211, 20)
        Me.TextBox3.TabIndex = 10
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(180, 60)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(211, 20)
        Me.TextBox1.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label7.Location = New System.Drawing.Point(436, 99)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(106, 28)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Issue Date"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label9.Location = New System.Drawing.Point(433, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(110, 37)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Student /staff (ID/RollNo)"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label10.Location = New System.Drawing.Point(33, 144)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(105, 23)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Book Author"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label11.Location = New System.Drawing.Point(37, 98)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 25)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Book Title"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label12.Location = New System.Drawing.Point(33, 55)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(105, 25)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Accession No"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'renewbtn
        '
        Me.renewbtn.BackColor = System.Drawing.Color.DarkSlateGray
        Me.renewbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.renewbtn.ForeColor = System.Drawing.Color.White
        Me.renewbtn.Location = New System.Drawing.Point(657, 145)
        Me.renewbtn.Name = "renewbtn"
        Me.renewbtn.Size = New System.Drawing.Size(109, 27)
        Me.renewbtn.TabIndex = 10
        Me.renewbtn.Text = "Renew book"
        Me.renewbtn.UseVisualStyleBackColor = False
        '
        'renewbookfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.ClientSize = New System.Drawing.Size(949, 450)
        Me.Controls.Add(Me.renewbtn)
        Me.Controls.Add(Me.detailpanel)
        Me.Controls.Add(Me.searchbtn)
        Me.Controls.Add(Me.renewdate)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "renewbookfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "renewbookfrm"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.detailpanel.ResumeLayout(False)
        Me.detailpanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents renewdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents searchbtn As System.Windows.Forms.Button
    Friend WithEvents detailpanel As System.Windows.Forms.Panel
    Friend WithEvents returndate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents issuedate As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents backbtn As System.Windows.Forms.Button
    Friend WithEvents refreshbtn As System.Windows.Forms.Button
    Friend WithEvents renewbtn As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
End Class
