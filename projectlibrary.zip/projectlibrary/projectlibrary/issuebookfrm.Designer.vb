﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class issuebookfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(issuebookfrm))
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.issuedate = New System.Windows.Forms.DateTimePicker()
        Me.issuebooksearch = New System.Windows.Forms.Button()
        Me.issueStaffsearch = New System.Windows.Forms.Button()
        Me.Issuebtn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.returndate = New System.Windows.Forms.DateTimePicker()
        Me.IssuePanel = New System.Windows.Forms.Panel()
        Me.issuerefreshBtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.backbtn = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.AccessionNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookTitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookAuthorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EditionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PublisherDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VendorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MediumDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookinfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LbdatabaseDataSet6 = New projectlibrary.lbdatabaseDataSet6()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.searchbookbtn = New System.Windows.Forms.Button()
        Me.BookinfoTableAdapter = New projectlibrary.lbdatabaseDataSet6TableAdapters.bookinfoTableAdapter()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.IssuePanel.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BookinfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LbdatabaseDataSet6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label12.Location = New System.Drawing.Point(32, 29)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(105, 25)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Accession No"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label11.Location = New System.Drawing.Point(36, 88)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 25)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Book Title"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label10.Location = New System.Drawing.Point(32, 126)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(105, 23)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Book Author"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label4.Location = New System.Drawing.Point(401, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(179, 37)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Student /staff (ID/RollNo)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label5.Location = New System.Drawing.Point(401, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(177, 34)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Student /Staff Name"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label6.Location = New System.Drawing.Point(401, 132)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(174, 34)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Department"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label7.Location = New System.Drawing.Point(31, 163)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(106, 28)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Issue Date"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(163, 34)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(211, 20)
        Me.TextBox1.TabIndex = 8
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(163, 93)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(211, 20)
        Me.TextBox2.TabIndex = 9
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(163, 129)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(211, 20)
        Me.TextBox3.TabIndex = 10
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(596, 35)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(211, 20)
        Me.TextBox4.TabIndex = 11
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(596, 102)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(211, 20)
        Me.TextBox5.TabIndex = 12
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(598, 141)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(211, 20)
        Me.TextBox6.TabIndex = 13
        '
        'issuedate
        '
        Me.issuedate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.issuedate.Location = New System.Drawing.Point(164, 171)
        Me.issuedate.Name = "issuedate"
        Me.issuedate.Size = New System.Drawing.Size(210, 20)
        Me.issuedate.TabIndex = 14
        '
        'issuebooksearch
        '
        Me.issuebooksearch.BackColor = System.Drawing.Color.Gray
        Me.issuebooksearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.issuebooksearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issuebooksearch.Location = New System.Drawing.Point(163, 60)
        Me.issuebooksearch.Name = "issuebooksearch"
        Me.issuebooksearch.Size = New System.Drawing.Size(78, 25)
        Me.issuebooksearch.TabIndex = 16
        Me.issuebooksearch.Text = "Search"
        Me.issuebooksearch.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.issuebooksearch.UseVisualStyleBackColor = False
        '
        'issueStaffsearch
        '
        Me.issueStaffsearch.BackColor = System.Drawing.Color.Gray
        Me.issueStaffsearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.issueStaffsearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issueStaffsearch.Location = New System.Drawing.Point(596, 61)
        Me.issueStaffsearch.Name = "issueStaffsearch"
        Me.issueStaffsearch.Size = New System.Drawing.Size(78, 25)
        Me.issueStaffsearch.TabIndex = 17
        Me.issueStaffsearch.Text = "Search"
        Me.issueStaffsearch.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.issueStaffsearch.UseVisualStyleBackColor = False
        '
        'Issuebtn
        '
        Me.Issuebtn.BackColor = System.Drawing.Color.Teal
        Me.Issuebtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Issuebtn.ForeColor = System.Drawing.Color.White
        Me.Issuebtn.Location = New System.Drawing.Point(615, 231)
        Me.Issuebtn.Name = "Issuebtn"
        Me.Issuebtn.Size = New System.Drawing.Size(156, 39)
        Me.Issuebtn.TabIndex = 19
        Me.Issuebtn.Text = "ISSUED"
        Me.Issuebtn.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label2.Location = New System.Drawing.Point(401, 187)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(174, 32)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Type"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Student", "Staff"})
        Me.ComboBox1.Location = New System.Drawing.Point(598, 195)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(209, 21)
        Me.ComboBox1.TabIndex = 23
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label3.Location = New System.Drawing.Point(31, 210)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 31)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Return Date"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'returndate
        '
        Me.returndate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.returndate.Location = New System.Drawing.Point(163, 212)
        Me.returndate.Name = "returndate"
        Me.returndate.Size = New System.Drawing.Size(210, 20)
        Me.returndate.TabIndex = 25
        '
        'IssuePanel
        '
        Me.IssuePanel.BackColor = System.Drawing.Color.DarkSlateGray
        Me.IssuePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.IssuePanel.Controls.Add(Me.returndate)
        Me.IssuePanel.Controls.Add(Me.Label3)
        Me.IssuePanel.Controls.Add(Me.ComboBox1)
        Me.IssuePanel.Controls.Add(Me.Label2)
        Me.IssuePanel.Controls.Add(Me.Issuebtn)
        Me.IssuePanel.Controls.Add(Me.issueStaffsearch)
        Me.IssuePanel.Controls.Add(Me.issuebooksearch)
        Me.IssuePanel.Controls.Add(Me.issuedate)
        Me.IssuePanel.Controls.Add(Me.TextBox6)
        Me.IssuePanel.Controls.Add(Me.TextBox5)
        Me.IssuePanel.Controls.Add(Me.TextBox4)
        Me.IssuePanel.Controls.Add(Me.TextBox3)
        Me.IssuePanel.Controls.Add(Me.TextBox2)
        Me.IssuePanel.Controls.Add(Me.TextBox1)
        Me.IssuePanel.Controls.Add(Me.Label7)
        Me.IssuePanel.Controls.Add(Me.Label6)
        Me.IssuePanel.Controls.Add(Me.Label5)
        Me.IssuePanel.Controls.Add(Me.Label4)
        Me.IssuePanel.Controls.Add(Me.Label10)
        Me.IssuePanel.Controls.Add(Me.Label11)
        Me.IssuePanel.Controls.Add(Me.Label12)
        Me.IssuePanel.Location = New System.Drawing.Point(68, 290)
        Me.IssuePanel.Name = "IssuePanel"
        Me.IssuePanel.Size = New System.Drawing.Size(848, 290)
        Me.IssuePanel.TabIndex = 8
        '
        'issuerefreshBtn
        '
        Me.issuerefreshBtn.BackColor = System.Drawing.Color.Teal
        Me.issuerefreshBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.issuerefreshBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issuerefreshBtn.ForeColor = System.Drawing.Color.White
        Me.issuerefreshBtn.Location = New System.Drawing.Point(675, 21)
        Me.issuerefreshBtn.Name = "issuerefreshBtn"
        Me.issuerefreshBtn.Size = New System.Drawing.Size(119, 29)
        Me.issuerefreshBtn.TabIndex = 20
        Me.issuerefreshBtn.Text = "REFRESH"
        Me.issuerefreshBtn.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(136, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(165, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ISSUE BOOKS"
        '
        'backbtn
        '
        Me.backbtn.BackColor = System.Drawing.Color.Teal
        Me.backbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.backbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbtn.ForeColor = System.Drawing.Color.White
        Me.backbtn.Location = New System.Drawing.Point(816, 21)
        Me.backbtn.Name = "backbtn"
        Me.backbtn.Size = New System.Drawing.Size(77, 29)
        Me.backbtn.TabIndex = 5
        Me.backbtn.Text = "Back"
        Me.backbtn.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel2.Controls.Add(Me.backbtn)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.issuerefreshBtn)
        Me.Panel2.Location = New System.Drawing.Point(23, 12)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(947, 64)
        Me.Panel2.TabIndex = 10
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AccessionNoDataGridViewTextBoxColumn, Me.BookTitleDataGridViewTextBoxColumn, Me.BookAuthorDataGridViewTextBoxColumn, Me.EditionDataGridViewTextBoxColumn, Me.BDateDataGridViewTextBoxColumn, Me.PublisherDataGridViewTextBoxColumn, Me.VendorDataGridViewTextBoxColumn, Me.PriceDataGridViewTextBoxColumn, Me.MediumDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.BookinfoBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(68, 122)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(643, 144)
        Me.DataGridView1.TabIndex = 11
        '
        'AccessionNoDataGridViewTextBoxColumn
        '
        Me.AccessionNoDataGridViewTextBoxColumn.DataPropertyName = "AccessionNo"
        Me.AccessionNoDataGridViewTextBoxColumn.HeaderText = "AccessionNo"
        Me.AccessionNoDataGridViewTextBoxColumn.Name = "AccessionNoDataGridViewTextBoxColumn"
        '
        'BookTitleDataGridViewTextBoxColumn
        '
        Me.BookTitleDataGridViewTextBoxColumn.DataPropertyName = "BookTitle"
        Me.BookTitleDataGridViewTextBoxColumn.HeaderText = "BookTitle"
        Me.BookTitleDataGridViewTextBoxColumn.Name = "BookTitleDataGridViewTextBoxColumn"
        '
        'BookAuthorDataGridViewTextBoxColumn
        '
        Me.BookAuthorDataGridViewTextBoxColumn.DataPropertyName = "BookAuthor"
        Me.BookAuthorDataGridViewTextBoxColumn.HeaderText = "BookAuthor"
        Me.BookAuthorDataGridViewTextBoxColumn.Name = "BookAuthorDataGridViewTextBoxColumn"
        '
        'EditionDataGridViewTextBoxColumn
        '
        Me.EditionDataGridViewTextBoxColumn.DataPropertyName = "Edition"
        Me.EditionDataGridViewTextBoxColumn.HeaderText = "Edition"
        Me.EditionDataGridViewTextBoxColumn.Name = "EditionDataGridViewTextBoxColumn"
        '
        'BDateDataGridViewTextBoxColumn
        '
        Me.BDateDataGridViewTextBoxColumn.DataPropertyName = "BDate"
        Me.BDateDataGridViewTextBoxColumn.HeaderText = "BDate"
        Me.BDateDataGridViewTextBoxColumn.Name = "BDateDataGridViewTextBoxColumn"
        '
        'PublisherDataGridViewTextBoxColumn
        '
        Me.PublisherDataGridViewTextBoxColumn.DataPropertyName = "Publisher"
        Me.PublisherDataGridViewTextBoxColumn.HeaderText = "Publisher"
        Me.PublisherDataGridViewTextBoxColumn.Name = "PublisherDataGridViewTextBoxColumn"
        '
        'VendorDataGridViewTextBoxColumn
        '
        Me.VendorDataGridViewTextBoxColumn.DataPropertyName = "Vendor"
        Me.VendorDataGridViewTextBoxColumn.HeaderText = "Vendor"
        Me.VendorDataGridViewTextBoxColumn.Name = "VendorDataGridViewTextBoxColumn"
        '
        'PriceDataGridViewTextBoxColumn
        '
        Me.PriceDataGridViewTextBoxColumn.DataPropertyName = "Price"
        Me.PriceDataGridViewTextBoxColumn.HeaderText = "Price"
        Me.PriceDataGridViewTextBoxColumn.Name = "PriceDataGridViewTextBoxColumn"
        '
        'MediumDataGridViewTextBoxColumn
        '
        Me.MediumDataGridViewTextBoxColumn.DataPropertyName = "Medium"
        Me.MediumDataGridViewTextBoxColumn.HeaderText = "Medium"
        Me.MediumDataGridViewTextBoxColumn.Name = "MediumDataGridViewTextBoxColumn"
        '
        'BookinfoBindingSource
        '
        Me.BookinfoBindingSource.DataMember = "bookinfo"
        Me.BookinfoBindingSource.DataSource = Me.LbdatabaseDataSet6
        '
        'LbdatabaseDataSet6
        '
        Me.LbdatabaseDataSet6.DataSetName = "lbdatabaseDataSet6"
        Me.LbdatabaseDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(717, 144)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(199, 20)
        Me.TextBox7.TabIndex = 12
        '
        'searchbookbtn
        '
        Me.searchbookbtn.BackColor = System.Drawing.Color.Teal
        Me.searchbookbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.searchbookbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchbookbtn.ForeColor = System.Drawing.Color.White
        Me.searchbookbtn.Location = New System.Drawing.Point(722, 181)
        Me.searchbookbtn.Name = "searchbookbtn"
        Me.searchbookbtn.Size = New System.Drawing.Size(194, 29)
        Me.searchbookbtn.TabIndex = 21
        Me.searchbookbtn.Text = "Search by AccessionNo."
        Me.searchbookbtn.UseVisualStyleBackColor = False
        '
        'BookinfoTableAdapter
        '
        Me.BookinfoTableAdapter.ClearBeforeFill = True
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(99, 93)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(210, 26)
        Me.Label8.TabIndex = 37
        Me.Label8.Text = "Library Book List" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'issuebookfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(991, 622)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.searchbookbtn)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.IssuePanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "issuebookfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IssueBook"
        Me.IssuePanel.ResumeLayout(False)
        Me.IssuePanel.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BookinfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LbdatabaseDataSet6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents issuedate As System.Windows.Forms.DateTimePicker
    Friend WithEvents issuebooksearch As System.Windows.Forms.Button
    Friend WithEvents issueStaffsearch As System.Windows.Forms.Button
    Friend WithEvents Issuebtn As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents returndate As System.Windows.Forms.DateTimePicker
    Friend WithEvents IssuePanel As System.Windows.Forms.Panel
    Friend WithEvents issuerefreshBtn As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents backbtn As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents searchbookbtn As System.Windows.Forms.Button
    Friend WithEvents LbdatabaseDataSet6 As projectlibrary.lbdatabaseDataSet6
    Friend WithEvents BookinfoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents BookinfoTableAdapter As projectlibrary.lbdatabaseDataSet6TableAdapters.bookinfoTableAdapter
    Friend WithEvents AccessionNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BookAuthorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EditionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PublisherDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VendorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PriceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MediumDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
