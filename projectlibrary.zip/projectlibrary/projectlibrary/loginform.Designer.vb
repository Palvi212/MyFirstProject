﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class loginform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.librianlogin = New System.Windows.Forms.Label()
        Me.adminlogin = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.forgotpassbtnlink = New System.Windows.Forms.LinkLabel()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel2.Controls.Add(Me.forgotpassbtnlink)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(-3, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(849, 69)
        Me.Panel2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(269, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(272, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "LOGIN TO THE SYSTEM"
        '
        'librianlogin
        '
        Me.librianlogin.BackColor = System.Drawing.Color.DarkCyan
        Me.librianlogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.librianlogin.ForeColor = System.Drawing.Color.White
        Me.librianlogin.Location = New System.Drawing.Point(12, 73)
        Me.librianlogin.Name = "librianlogin"
        Me.librianlogin.Size = New System.Drawing.Size(399, 30)
        Me.librianlogin.TabIndex = 2
        Me.librianlogin.Text = "LIBRIAN LOGIN"
        Me.librianlogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'adminlogin
        '
        Me.adminlogin.BackColor = System.Drawing.Color.DarkCyan
        Me.adminlogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adminlogin.ForeColor = System.Drawing.Color.White
        Me.adminlogin.Location = New System.Drawing.Point(426, 73)
        Me.adminlogin.Name = "adminlogin"
        Me.adminlogin.Size = New System.Drawing.Size(405, 30)
        Me.adminlogin.TabIndex = 3
        Me.adminlogin.Text = "ADMIN LOGIN"
        Me.adminlogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PowderBlue
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Location = New System.Drawing.Point(-3, 114)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(849, 380)
        Me.Panel1.TabIndex = 0
        '
        'forgotpassbtnlink
        '
        Me.forgotpassbtnlink.AutoSize = True
        Me.forgotpassbtnlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.forgotpassbtnlink.LinkColor = System.Drawing.Color.White
        Me.forgotpassbtnlink.Location = New System.Drawing.Point(711, 40)
        Me.forgotpassbtnlink.Name = "forgotpassbtnlink"
        Me.forgotpassbtnlink.Size = New System.Drawing.Size(123, 18)
        Me.forgotpassbtnlink.TabIndex = 14
        Me.forgotpassbtnlink.TabStop = True
        Me.forgotpassbtnlink.Text = "Forgot Password" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.forgotpassbtnlink.VisitedLinkColor = System.Drawing.Color.Red
        '
        'loginform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.ClientSize = New System.Drawing.Size(843, 491)
        Me.Controls.Add(Me.adminlogin)
        Me.Controls.Add(Me.librianlogin)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "loginform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "loginform"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents librianlogin As System.Windows.Forms.Label
    Friend WithEvents adminlogin As System.Windows.Forms.Label
    Friend WithEvents forgotpassbtnlink As System.Windows.Forms.LinkLabel
End Class
