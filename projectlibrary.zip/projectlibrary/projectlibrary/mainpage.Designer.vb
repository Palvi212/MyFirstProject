﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainpage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mainpage))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TRANSACTIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ISSUEBOOKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TransactionToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IssueBookToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReturnBookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.returnbookbtn = New System.Windows.Forms.Label()
        Me.issuebookbtn = New System.Windows.Forms.Label()
        Me.searchbookbtn = New System.Windows.Forms.Label()
        Me.managebookbtn = New System.Windows.Forms.Label()
        Me.managestudentbtn = New System.Windows.Forms.Label()
        Me.viewrecordbtn = New System.Windows.Forms.Label()
        Me.logoutbtn = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.renewbookbtn = New System.Windows.Forms.Label()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.managestffbtn = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label1.Font = New System.Drawing.Font("Footlight MT Light", 36.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SandyBrown
        Me.Label1.Location = New System.Drawing.Point(1, -1)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(65, 0, 0, 0)
        Me.Label1.Size = New System.Drawing.Size(1086, 83)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "VATIKA GAYAN LIBRARY "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TRANSACTIONToolStripMenuItem
        '
        Me.TRANSACTIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentToolStripMenuItem, Me.ISSUEBOOKToolStripMenuItem, Me.BookToolStripMenuItem})
        Me.TRANSACTIONToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TRANSACTIONToolStripMenuItem.Name = "TRANSACTIONToolStripMenuItem"
        Me.TRANSACTIONToolStripMenuItem.Size = New System.Drawing.Size(107, 28)
        Me.TRANSACTIONToolStripMenuItem.Text = "Master Entery"
        '
        'StudentToolStripMenuItem
        '
        Me.StudentToolStripMenuItem.BackColor = System.Drawing.Color.SkyBlue
        Me.StudentToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentToolStripMenuItem.Name = "StudentToolStripMenuItem"
        Me.StudentToolStripMenuItem.Size = New System.Drawing.Size(126, 24)
        Me.StudentToolStripMenuItem.Text = "Student"
        '
        'ISSUEBOOKToolStripMenuItem
        '
        Me.ISSUEBOOKToolStripMenuItem.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ISSUEBOOKToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ISSUEBOOKToolStripMenuItem.Name = "ISSUEBOOKToolStripMenuItem"
        Me.ISSUEBOOKToolStripMenuItem.Size = New System.Drawing.Size(126, 24)
        Me.ISSUEBOOKToolStripMenuItem.Text = "Staff"
        '
        'BookToolStripMenuItem
        '
        Me.BookToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.BookToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BookToolStripMenuItem.Name = "BookToolStripMenuItem"
        Me.BookToolStripMenuItem.Size = New System.Drawing.Size(126, 24)
        Me.BookToolStripMenuItem.Text = "Book"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.CadetBlue
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TRANSACTIONToolStripMenuItem, Me.TransactionToolStripMenuItem1, Me.RecordsToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.LogoutInfoToolStripMenuItem, Me.BackupDataToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(1, 82)
        Me.MenuStrip1.Margin = New System.Windows.Forms.Padding(0, 30, 0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1086, 32)
        Me.MenuStrip1.TabIndex = 42
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TransactionToolStripMenuItem1
        '
        Me.TransactionToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IssueBookToolStripMenuItem1, Me.ReturnBookToolStripMenuItem})
        Me.TransactionToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TransactionToolStripMenuItem1.Name = "TransactionToolStripMenuItem1"
        Me.TransactionToolStripMenuItem1.Size = New System.Drawing.Size(96, 28)
        Me.TransactionToolStripMenuItem1.Text = "Transaction"
        '
        'IssueBookToolStripMenuItem1
        '
        Me.IssueBookToolStripMenuItem1.BackColor = System.Drawing.Color.DarkTurquoise
        Me.IssueBookToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IssueBookToolStripMenuItem1.Name = "IssueBookToolStripMenuItem1"
        Me.IssueBookToolStripMenuItem1.Size = New System.Drawing.Size(156, 24)
        Me.IssueBookToolStripMenuItem1.Text = "Issue Book"
        '
        'ReturnBookToolStripMenuItem
        '
        Me.ReturnBookToolStripMenuItem.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.ReturnBookToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnBookToolStripMenuItem.Name = "ReturnBookToolStripMenuItem"
        Me.ReturnBookToolStripMenuItem.Size = New System.Drawing.Size(156, 24)
        Me.ReturnBookToolStripMenuItem.Text = "Return Book"
        '
        'RecordsToolStripMenuItem
        '
        Me.RecordsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RecordsToolStripMenuItem.Name = "RecordsToolStripMenuItem"
        Me.RecordsToolStripMenuItem.Size = New System.Drawing.Size(71, 28)
        Me.RecordsToolStripMenuItem.Text = "Records"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(71, 28)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'LogoutInfoToolStripMenuItem
        '
        Me.LogoutInfoToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutInfoToolStripMenuItem.Name = "LogoutInfoToolStripMenuItem"
        Me.LogoutInfoToolStripMenuItem.Size = New System.Drawing.Size(65, 28)
        Me.LogoutInfoToolStripMenuItem.Text = "Logout"
        '
        'BackupDataToolStripMenuItem
        '
        Me.BackupDataToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BackupDataToolStripMenuItem.Name = "BackupDataToolStripMenuItem"
        Me.BackupDataToolStripMenuItem.Size = New System.Drawing.Size(104, 28)
        Me.BackupDataToolStripMenuItem.Text = "Backup Data"
        '
        'returnbookbtn
        '
        Me.returnbookbtn.AutoSize = True
        Me.returnbookbtn.BackColor = System.Drawing.Color.Teal
        Me.returnbookbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.returnbookbtn.ForeColor = System.Drawing.Color.White
        Me.returnbookbtn.Location = New System.Drawing.Point(603, 63)
        Me.returnbookbtn.Name = "returnbookbtn"
        Me.returnbookbtn.Size = New System.Drawing.Size(96, 15)
        Me.returnbookbtn.TabIndex = 18
        Me.returnbookbtn.Text = "Return Books"
        Me.returnbookbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'issuebookbtn
        '
        Me.issuebookbtn.AutoSize = True
        Me.issuebookbtn.BackColor = System.Drawing.Color.Teal
        Me.issuebookbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issuebookbtn.ForeColor = System.Drawing.Color.White
        Me.issuebookbtn.Location = New System.Drawing.Point(496, 63)
        Me.issuebookbtn.Name = "issuebookbtn"
        Me.issuebookbtn.Size = New System.Drawing.Size(86, 15)
        Me.issuebookbtn.TabIndex = 15
        Me.issuebookbtn.Text = "Issue Books"
        Me.issuebookbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'searchbookbtn
        '
        Me.searchbookbtn.AutoSize = True
        Me.searchbookbtn.BackColor = System.Drawing.Color.Teal
        Me.searchbookbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchbookbtn.ForeColor = System.Drawing.Color.White
        Me.searchbookbtn.Location = New System.Drawing.Point(378, 63)
        Me.searchbookbtn.Name = "searchbookbtn"
        Me.searchbookbtn.Size = New System.Drawing.Size(96, 15)
        Me.searchbookbtn.TabIndex = 37
        Me.searchbookbtn.Text = "Search Books"
        Me.searchbookbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'managebookbtn
        '
        Me.managebookbtn.AutoSize = True
        Me.managebookbtn.BackColor = System.Drawing.Color.Teal
        Me.managebookbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.managebookbtn.ForeColor = System.Drawing.Color.White
        Me.managebookbtn.Location = New System.Drawing.Point(259, 63)
        Me.managebookbtn.Name = "managebookbtn"
        Me.managebookbtn.Size = New System.Drawing.Size(99, 15)
        Me.managebookbtn.TabIndex = 8
        Me.managebookbtn.Text = "Manage Books"
        Me.managebookbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'managestudentbtn
        '
        Me.managestudentbtn.AutoSize = True
        Me.managestudentbtn.BackColor = System.Drawing.Color.Teal
        Me.managestudentbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.managestudentbtn.ForeColor = System.Drawing.Color.White
        Me.managestudentbtn.Location = New System.Drawing.Point(24, 63)
        Me.managestudentbtn.Name = "managestudentbtn"
        Me.managestudentbtn.Size = New System.Drawing.Size(107, 15)
        Me.managestudentbtn.TabIndex = 6
        Me.managestudentbtn.Text = "Manage Student" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.managestudentbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'viewrecordbtn
        '
        Me.viewrecordbtn.AutoSize = True
        Me.viewrecordbtn.BackColor = System.Drawing.Color.Teal
        Me.viewrecordbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.viewrecordbtn.ForeColor = System.Drawing.Color.White
        Me.viewrecordbtn.Location = New System.Drawing.Point(841, 63)
        Me.viewrecordbtn.Name = "viewrecordbtn"
        Me.viewrecordbtn.Size = New System.Drawing.Size(97, 15)
        Me.viewrecordbtn.TabIndex = 35
        Me.viewrecordbtn.Text = "View Records"
        Me.viewrecordbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'logoutbtn
        '
        Me.logoutbtn.AutoSize = True
        Me.logoutbtn.BackColor = System.Drawing.Color.Teal
        Me.logoutbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logoutbtn.ForeColor = System.Drawing.Color.White
        Me.logoutbtn.Location = New System.Drawing.Point(974, 63)
        Me.logoutbtn.Name = "logoutbtn"
        Me.logoutbtn.Size = New System.Drawing.Size(52, 15)
        Me.logoutbtn.TabIndex = 41
        Me.logoutbtn.Text = "Logout"
        Me.logoutbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.Controls.Add(Me.renewbookbtn)
        Me.Panel1.Controls.Add(Me.PictureBox11)
        Me.Panel1.Controls.Add(Me.PictureBox8)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Controls.Add(Me.viewrecordbtn)
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.managestffbtn)
        Me.Panel1.Controls.Add(Me.logoutbtn)
        Me.Panel1.Controls.Add(Me.returnbookbtn)
        Me.Panel1.Controls.Add(Me.issuebookbtn)
        Me.Panel1.Controls.Add(Me.managestudentbtn)
        Me.Panel1.Controls.Add(Me.searchbookbtn)
        Me.Panel1.Controls.Add(Me.managebookbtn)
        Me.Panel1.Location = New System.Drawing.Point(1, 111)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1086, 95)
        Me.Panel1.TabIndex = 44
        '
        'renewbookbtn
        '
        Me.renewbookbtn.AutoSize = True
        Me.renewbookbtn.BackColor = System.Drawing.Color.Teal
        Me.renewbookbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.renewbookbtn.ForeColor = System.Drawing.Color.White
        Me.renewbookbtn.Location = New System.Drawing.Point(721, 63)
        Me.renewbookbtn.Name = "renewbookbtn"
        Me.renewbookbtn.Size = New System.Drawing.Size(95, 15)
        Me.renewbookbtn.TabIndex = 55
        Me.renewbookbtn.Text = "Renew Books"
        Me.renewbookbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox11
        '
        Me.PictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(739, 23)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(52, 37)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 54
        Me.PictureBox11.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(864, 23)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(50, 37)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 52
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(977, 23)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(49, 37)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 53
        Me.PictureBox9.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(624, 23)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(48, 37)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 51
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(513, 23)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(46, 37)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 50
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(400, 23)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(50, 37)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 49
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(284, 23)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(52, 37)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 48
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(169, 23)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(53, 37)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 47
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(49, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(53, 37)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 46
        Me.PictureBox1.TabStop = False
        '
        'managestffbtn
        '
        Me.managestffbtn.AutoSize = True
        Me.managestffbtn.BackColor = System.Drawing.Color.Teal
        Me.managestffbtn.Font = New System.Drawing.Font("Lucida Bright", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.managestffbtn.ForeColor = System.Drawing.Color.White
        Me.managestffbtn.Location = New System.Drawing.Point(150, 63)
        Me.managestffbtn.Name = "managestffbtn"
        Me.managestffbtn.Size = New System.Drawing.Size(87, 15)
        Me.managestffbtn.TabIndex = 45
        Me.managestffbtn.Text = "Manage Staff"
        Me.managestffbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox7
        '
        Me.PictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(50, 12)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(123, 60)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 1
        Me.PictureBox7.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(1, 202)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(1086, 324)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 45
        Me.PictureBox10.TabStop = False
        '
        'mainpage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.Color.SeaShell
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1088, 526)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox10)
        Me.HelpButton = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "mainpage"
        Me.Text = "mainpage"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents TRANSACTIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ISSUEBOOKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents StudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IssueBookToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReturnBookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecordsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents returnbookbtn As System.Windows.Forms.Label
    Friend WithEvents issuebookbtn As System.Windows.Forms.Label
    Friend WithEvents searchbookbtn As System.Windows.Forms.Label
    Friend WithEvents managebookbtn As System.Windows.Forms.Label
    Friend WithEvents managestudentbtn As System.Windows.Forms.Label
    Friend WithEvents viewrecordbtn As System.Windows.Forms.Label
    Friend WithEvents logoutbtn As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents managestffbtn As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents BackupDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents renewbookbtn As System.Windows.Forms.Label
End Class
