﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class returnbookfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(returnbookfrm))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.backbtn = New System.Windows.Forms.Button()
        Me.issuerefreshBtn = New System.Windows.Forms.Button()
        Me.IssuePanel = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.issuedate = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.todaydate = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Returnbtn = New System.Windows.Forms.Button()
        Me.returnbooksearch = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.AccessionNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BooKTitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AuthorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IdRollnoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DepartmentDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IssueDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReturnDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IssuebookBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LbdatabaseDataSet4 = New projectlibrary.lbdatabaseDataSet4()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.search = New System.Windows.Forms.Button()
        Me.IssuebookTableAdapter = New projectlibrary.lbdatabaseDataSet4TableAdapters.issuebookTableAdapter()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.returndate = New System.Windows.Forms.DateTimePicker()
        Me.IssuePanel.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IssuebookBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LbdatabaseDataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Felix Titling", 27.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.Label1.Location = New System.Drawing.Point(19, 12)
        Me.Label1.Margin = New System.Windows.Forms.Padding(10)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(90, 0, 0, 0)
        Me.Label1.Size = New System.Drawing.Size(1034, 71)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "RETURN BOOKS"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'backbtn
        '
        Me.backbtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.backbtn.BackColor = System.Drawing.Color.Teal
        Me.backbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.backbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbtn.ForeColor = System.Drawing.Color.White
        Me.backbtn.Location = New System.Drawing.Point(757, 23)
        Me.backbtn.Name = "backbtn"
        Me.backbtn.Size = New System.Drawing.Size(97, 37)
        Me.backbtn.TabIndex = 31
        Me.backbtn.Text = "Back"
        Me.backbtn.UseVisualStyleBackColor = False
        '
        'issuerefreshBtn
        '
        Me.issuerefreshBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.issuerefreshBtn.BackColor = System.Drawing.Color.Teal
        Me.issuerefreshBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.issuerefreshBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issuerefreshBtn.ForeColor = System.Drawing.Color.White
        Me.issuerefreshBtn.Location = New System.Drawing.Point(876, 24)
        Me.issuerefreshBtn.Name = "issuerefreshBtn"
        Me.issuerefreshBtn.Size = New System.Drawing.Size(105, 36)
        Me.issuerefreshBtn.TabIndex = 32
        Me.issuerefreshBtn.Text = "REFRESH"
        Me.issuerefreshBtn.UseVisualStyleBackColor = False
        '
        'IssuePanel
        '
        Me.IssuePanel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.IssuePanel.BackColor = System.Drawing.Color.DarkSlateGray
        Me.IssuePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.IssuePanel.Controls.Add(Me.returndate)
        Me.IssuePanel.Controls.Add(Me.Label5)
        Me.IssuePanel.Controls.Add(Me.issuedate)
        Me.IssuePanel.Controls.Add(Me.TextBox9)
        Me.IssuePanel.Controls.Add(Me.TextBox8)
        Me.IssuePanel.Controls.Add(Me.Label13)
        Me.IssuePanel.Controls.Add(Me.todaydate)
        Me.IssuePanel.Controls.Add(Me.Label8)
        Me.IssuePanel.Controls.Add(Me.Label3)
        Me.IssuePanel.Controls.Add(Me.ComboBox1)
        Me.IssuePanel.Controls.Add(Me.Label2)
        Me.IssuePanel.Controls.Add(Me.Returnbtn)
        Me.IssuePanel.Controls.Add(Me.returnbooksearch)
        Me.IssuePanel.Controls.Add(Me.TextBox4)
        Me.IssuePanel.Controls.Add(Me.TextBox2)
        Me.IssuePanel.Controls.Add(Me.TextBox1)
        Me.IssuePanel.Controls.Add(Me.Label7)
        Me.IssuePanel.Controls.Add(Me.Label4)
        Me.IssuePanel.Controls.Add(Me.Label11)
        Me.IssuePanel.Controls.Add(Me.Label12)
        Me.IssuePanel.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.IssuePanel.Location = New System.Drawing.Point(71, 298)
        Me.IssuePanel.Name = "IssuePanel"
        Me.IssuePanel.Size = New System.Drawing.Size(927, 282)
        Me.IssuePanel.TabIndex = 33
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.DarkCyan
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(489, 187)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 25)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Fine "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'issuedate
        '
        Me.issuedate.Enabled = False
        Me.issuedate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issuedate.Location = New System.Drawing.Point(243, 190)
        Me.issuedate.Name = "issuedate"
        Me.issuedate.Size = New System.Drawing.Size(211, 22)
        Me.issuedate.TabIndex = 32
        '
        'TextBox9
        '
        Me.TextBox9.Enabled = False
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(671, 190)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(211, 22)
        Me.TextBox9.TabIndex = 31
        '
        'TextBox8
        '
        Me.TextBox8.Enabled = False
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(670, 149)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(211, 22)
        Me.TextBox8.TabIndex = 29
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.DarkCyan
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(488, 146)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(136, 25)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "Delay"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'todaydate
        '
        Me.todaydate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.todaydate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.todaydate.Location = New System.Drawing.Point(671, 76)
        Me.todaydate.Name = "todaydate"
        Me.todaydate.Size = New System.Drawing.Size(210, 22)
        Me.todaydate.TabIndex = 27
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.DarkCyan
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(489, 76)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(136, 25)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Today Date"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.DarkCyan
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(489, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 30)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Return Date"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox1
        '
        Me.ComboBox1.Enabled = False
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Student", "Staff"})
        Me.ComboBox1.Location = New System.Drawing.Point(670, 112)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(209, 24)
        Me.ComboBox1.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.DarkCyan
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(488, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(137, 21)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Type"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Returnbtn
        '
        Me.Returnbtn.BackColor = System.Drawing.Color.Teal
        Me.Returnbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Returnbtn.Location = New System.Drawing.Point(675, 233)
        Me.Returnbtn.Name = "Returnbtn"
        Me.Returnbtn.Size = New System.Drawing.Size(207, 36)
        Me.Returnbtn.TabIndex = 19
        Me.Returnbtn.Text = "RETURN"
        Me.Returnbtn.UseVisualStyleBackColor = False
        '
        'returnbooksearch
        '
        Me.returnbooksearch.BackColor = System.Drawing.Color.Teal
        Me.returnbooksearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.returnbooksearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.returnbooksearch.Location = New System.Drawing.Point(244, 63)
        Me.returnbooksearch.Name = "returnbooksearch"
        Me.returnbooksearch.Size = New System.Drawing.Size(78, 25)
        Me.returnbooksearch.TabIndex = 16
        Me.returnbooksearch.Text = "Search"
        Me.returnbooksearch.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.returnbooksearch.UseVisualStyleBackColor = False
        '
        'TextBox4
        '
        Me.TextBox4.Enabled = False
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(242, 149)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(211, 22)
        Me.TextBox4.TabIndex = 11
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(242, 113)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(211, 22)
        Me.TextBox2.TabIndex = 9
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(242, 37)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(211, 22)
        Me.TextBox1.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.DarkCyan
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(30, 194)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(181, 25)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Issue Date"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.DarkCyan
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(29, 149)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(182, 29)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Student /staff (ID/RollNo)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.DarkCyan
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(30, 109)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(181, 24)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Book Title"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.DarkCyan
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(29, 37)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(182, 28)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Accession No"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AccessionNoDataGridViewTextBoxColumn, Me.BooKTitleDataGridViewTextBoxColumn, Me.AuthorDataGridViewTextBoxColumn, Me.IdRollnoDataGridViewTextBoxColumn, Me.SNameDataGridViewTextBoxColumn, Me.DepartmentDataGridViewTextBoxColumn, Me.TypeDataGridViewTextBoxColumn, Me.IssueDateDataGridViewTextBoxColumn, Me.ReturnDateDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.IssuebookBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(91, 124)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(693, 150)
        Me.DataGridView1.TabIndex = 34
        '
        'AccessionNoDataGridViewTextBoxColumn
        '
        Me.AccessionNoDataGridViewTextBoxColumn.DataPropertyName = "AccessionNo"
        Me.AccessionNoDataGridViewTextBoxColumn.HeaderText = "AccessionNo"
        Me.AccessionNoDataGridViewTextBoxColumn.Name = "AccessionNoDataGridViewTextBoxColumn"
        '
        'BooKTitleDataGridViewTextBoxColumn
        '
        Me.BooKTitleDataGridViewTextBoxColumn.DataPropertyName = "BooKTitle"
        Me.BooKTitleDataGridViewTextBoxColumn.HeaderText = "BooKTitle"
        Me.BooKTitleDataGridViewTextBoxColumn.Name = "BooKTitleDataGridViewTextBoxColumn"
        '
        'AuthorDataGridViewTextBoxColumn
        '
        Me.AuthorDataGridViewTextBoxColumn.DataPropertyName = "Author"
        Me.AuthorDataGridViewTextBoxColumn.HeaderText = "Author"
        Me.AuthorDataGridViewTextBoxColumn.Name = "AuthorDataGridViewTextBoxColumn"
        '
        'IdRollnoDataGridViewTextBoxColumn
        '
        Me.IdRollnoDataGridViewTextBoxColumn.DataPropertyName = "idRollno"
        Me.IdRollnoDataGridViewTextBoxColumn.HeaderText = "idRollno"
        Me.IdRollnoDataGridViewTextBoxColumn.Name = "IdRollnoDataGridViewTextBoxColumn"
        '
        'SNameDataGridViewTextBoxColumn
        '
        Me.SNameDataGridViewTextBoxColumn.DataPropertyName = "SName"
        Me.SNameDataGridViewTextBoxColumn.HeaderText = "SName"
        Me.SNameDataGridViewTextBoxColumn.Name = "SNameDataGridViewTextBoxColumn"
        '
        'DepartmentDataGridViewTextBoxColumn
        '
        Me.DepartmentDataGridViewTextBoxColumn.DataPropertyName = "Department"
        Me.DepartmentDataGridViewTextBoxColumn.HeaderText = "Department"
        Me.DepartmentDataGridViewTextBoxColumn.Name = "DepartmentDataGridViewTextBoxColumn"
        '
        'TypeDataGridViewTextBoxColumn
        '
        Me.TypeDataGridViewTextBoxColumn.DataPropertyName = "Type"
        Me.TypeDataGridViewTextBoxColumn.HeaderText = "Type"
        Me.TypeDataGridViewTextBoxColumn.Name = "TypeDataGridViewTextBoxColumn"
        '
        'IssueDateDataGridViewTextBoxColumn
        '
        Me.IssueDateDataGridViewTextBoxColumn.DataPropertyName = "issueDate"
        Me.IssueDateDataGridViewTextBoxColumn.HeaderText = "issueDate"
        Me.IssueDateDataGridViewTextBoxColumn.Name = "IssueDateDataGridViewTextBoxColumn"
        '
        'ReturnDateDataGridViewTextBoxColumn
        '
        Me.ReturnDateDataGridViewTextBoxColumn.DataPropertyName = "returnDate"
        Me.ReturnDateDataGridViewTextBoxColumn.HeaderText = "returnDate"
        Me.ReturnDateDataGridViewTextBoxColumn.Name = "ReturnDateDataGridViewTextBoxColumn"
        '
        'IssuebookBindingSource
        '
        Me.IssuebookBindingSource.DataMember = "issuebook"
        Me.IssuebookBindingSource.DataSource = Me.LbdatabaseDataSet4
        '
        'LbdatabaseDataSet4
        '
        Me.LbdatabaseDataSet4.DataSetName = "lbdatabaseDataSet4"
        Me.LbdatabaseDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(790, 148)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(189, 20)
        Me.TextBox3.TabIndex = 34
        '
        'search
        '
        Me.search.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.search.BackColor = System.Drawing.Color.Teal
        Me.search.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.search.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.search.ForeColor = System.Drawing.Color.White
        Me.search.Location = New System.Drawing.Point(790, 186)
        Me.search.Name = "search"
        Me.search.Size = New System.Drawing.Size(189, 36)
        Me.search.TabIndex = 35
        Me.search.Text = "Search by AccessionNo."
        Me.search.UseVisualStyleBackColor = False
        '
        'IssuebookTableAdapter
        '
        Me.IssuebookTableAdapter.ClearBeforeFill = True
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(100, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(210, 26)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Issued Book List"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'returndate
        '
        Me.returndate.Enabled = False
        Me.returndate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.returndate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.returndate.Location = New System.Drawing.Point(669, 35)
        Me.returndate.Name = "returndate"
        Me.returndate.Size = New System.Drawing.Size(210, 22)
        Me.returndate.TabIndex = 34
        '
        'returnbookfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1072, 613)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.search)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.IssuePanel)
        Me.Controls.Add(Me.backbtn)
        Me.Controls.Add(Me.issuerefreshBtn)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "returnbookfrm"
        Me.Text = "returnbookfrm"
        Me.IssuePanel.ResumeLayout(False)
        Me.IssuePanel.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IssuebookBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LbdatabaseDataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents backbtn As System.Windows.Forms.Button
    Friend WithEvents issuerefreshBtn As System.Windows.Forms.Button
    Friend WithEvents IssuePanel As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents issuedate As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents todaydate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Returnbtn As System.Windows.Forms.Button
    Friend WithEvents returnbooksearch As System.Windows.Forms.Button
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents search As System.Windows.Forms.Button
    Friend WithEvents LbdatabaseDataSet4 As projectlibrary.lbdatabaseDataSet4
    Friend WithEvents IssuebookBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents IssuebookTableAdapter As projectlibrary.lbdatabaseDataSet4TableAdapters.issuebookTableAdapter
    Friend WithEvents AccessionNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BooKTitleDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AuthorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IdRollnoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DepartmentDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TypeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IssueDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReturnDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents returndate As System.Windows.Forms.DateTimePicker
End Class
