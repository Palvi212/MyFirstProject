﻿Imports System.Data
Imports System.Data.OleDb
Public Class returnedbookdetail
    Private Sub gridview()
        openconn()
        cmd = New OleDbCommand("select * from returnbook", conn)
        da = New OleDbDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "returnbook")
        DataGridView2.DataSource = ds.Tables("returnbook")
        conn.Close()
    End Sub
    Private Sub searchreturnedbook_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchreturnedbook.Click
        If TextBox1.Text = "" Then
            MsgBox("Enter Book AccessionNo")
            TextBox1.Focus()
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select * from returnbook where AccessionNo='" & TextBox1.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox1.Text = rdr.Item("AccessionNo")
            Else
                MessageBox.Show("Book not Found")
                TextBox1.Focus()
                Exit Sub
            End If
            cmd = New OleDbCommand("select * from returnbook where AccessionNo='" & TextBox1.Text & "'", conn)
            da = New OleDbDataAdapter(cmd)
            ds = New DataSet
            da.Fill(ds, "returnbook")
            DataGridView2.DataSource = ds.Tables("returnbook")
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub

    Private Sub allrecordbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles allrecordbtn.Click
        gridview()
    End Sub

    Private Sub returnedbookdetail_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        gridview()
    End Sub
End Class
