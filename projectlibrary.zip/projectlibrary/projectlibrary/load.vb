﻿Public Class load

    Private Sub load_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value <= ProgressBar1.Maximum - 1 Then
            ProgressBar1.Value += 2
        End If
        If (ProgressBar1.Value = ProgressBar1.Maximum) Then
            Timer1.Enabled = False
            Me.Hide()
            loginform.Show()
        End If
    End Sub
End Class