﻿Imports System.Data
Imports System.Data.OleDb
Public Class Changepassword

    Private Sub okbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okbtn.Click
        If TextBox1.Text = "" Then
            MessageBox.Show("Please enter the current password!", "Change Password")
            TextBox1.Focus()
            Exit Sub
        End If
        Panel2.Show()
    End Sub

    Private Sub Changepassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Panel2.Hide()
    End Sub

    Private Sub savebtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles savebtn.Click
        If TextBox2.Text = "" Then
            MessageBox.Show("Please Enter UserID")
            Exit Sub
        ElseIf Password() = False Then
            MsgBox("Password Should be atleast 8 digit/character long", MsgBoxStyle.Information)
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDb.OleDbCommand("Select * from login where  Userid='" & TextBox2.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox2.Text = rdr.Item("Userid")
            Else
                MsgBox("Incorrect Userid", MsgBoxStyle.Information)
                TextBox2.Focus()
                Exit Sub
            End If
            cmd = New OleDb.OleDbCommand("update login set [Password]='" & TextBox3.Text & "' where [Userid]='" & TextBox2.Text & "'", conn)
            cmd.ExecuteNonQuery()
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            MessageBox.Show("Password Changed Successfully", "Settings")
            TextBox1.Clear()
            Panel2.Hide()
            TextBox2.Clear()
            TextBox3.Clear()
            Me.Hide()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    'check validation for Password
    Private Function Password()
        If TextBox3.TextLength < 8 = True Then
            TextBox3.Focus()
            Return False
        End If
        Return True
    End Function

    Private Sub Exitbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exitbtn.Click
        loginform.Show()
        Me.Hide()
    End Sub
End Class
