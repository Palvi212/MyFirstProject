﻿Imports System.Data
Imports System.Data.OleDb
Public Class issuedbookdetail
    Private Sub gridview()
        openconn()
        Dim sql As String = "select * from issuebook"
        da = New OleDbDataAdapter(sql, conn)
        ds = New DataSet
        da.Fill(ds, "issuebook")
        DataGridView1.DataSource = ds.Tables("issuebook")
        conn.Close()
    End Sub
    Private Sub issuedbookdetail_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        gridview()
    End Sub

    Private Sub searchissuedlistbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchissuedlistbtn.Click
        If TextBox1.Text = "" Then
            MsgBox("Enter Book AccessionNo")
            TextBox1.Focus()
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select * from issuebook where AccessionNo='" & TextBox1.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox1.Text = rdr.Item("AccessionNo")
            Else
                MessageBox.Show("Book not Found")
                TextBox1.Focus()
                Exit Sub
            End If
            cmd = New OleDbCommand("select * from issuebook where AccessionNo='" & TextBox1.Text & "'", conn)
            da = New OleDbDataAdapter(cmd)
            ds = New DataSet
            da.Fill(ds, "issuebook")
            DataGridView1.DataSource = ds.Tables("issuebook")
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub

    Private Sub allrecordbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles allrecordbtn.Click
        gridview()
    End Sub
End Class
