﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Text.RegularExpressions
Public Class settingfrm
    Private Sub settingfrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Panel2.Hide()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MessageBox.Show("Please enter the current password!", "Change Password")
            TextBox1.Focus()
            Exit Sub
        End If
        Panel2.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox2.Text = "" Then
            MessageBox.Show("Please Enter UserID")
            Exit Sub
        ElseIf ValidEmail() = False Then
            MsgBox("Email Address is Not Valid", MsgBoxStyle.Critical)
            Exit Sub
        ElseIf Password() = False Then
            MsgBox("Password Should be atleast 8 digit/character long", MsgBoxStyle.Information)
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDb.OleDbCommand("Select * from login where  Userid='" & TextBox2.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox2.Text = rdr.Item("Userid")
            Else
                MsgBox("Incorrect Userid", MsgBoxStyle.Information)
                TextBox2.Focus()
                Exit Sub
            End If
            cmd = New OleDb.OleDbCommand("update login set [Email]='" & TextBox3.Text & "',[Password]='" & TextBox4.Text & "' where [Userid]='" & TextBox2.Text & "'", conn)
            cmd.ExecuteNonQuery()
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            MessageBox.Show("Password Changed Successfully", "Settings")
            TextBox1.Clear()
            Panel2.Hide()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'check validation for email
    Private Function ValidEmail()
        Dim p As String
        p = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z]*@[0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Regex.IsMatch(TextBox3.Text, p) = False Then
            TextBox3.Focus()
            Return False
        End If
        Return True
    End Function
    'check validation for Password
    Private Function Password()
        If TextBox4.TextLength < 8 = True Then
            TextBox4.Focus()
            Return False
        End If
        Return True
    End Function
End Class