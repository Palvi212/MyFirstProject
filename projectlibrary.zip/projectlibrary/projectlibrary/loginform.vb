﻿Public Class loginform
    Private Sub switchpanel(ByVal panel As UserControl)
        Panel1.Controls.Clear()
        panel.Top = False
        Panel1.Controls.Add(panel)
    End Sub
    Private Sub librianlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles librianlogin.Click
        Dim librianbtn As New librianlogin
        switchpanel(librianbtn)
        librianlogin.BackColor = Color.LightSeaGreen
        adminlogin.BackColor = Color.DarkCyan
    End Sub

    Private Sub adminlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles adminlogin.Click
        Dim adminbtn As New adminllogin
        switchpanel(adminbtn)
        adminlogin.BackColor = Color.LightSeaGreen
        librianlogin.BackColor = Color.DarkCyan
    End Sub

    Private Sub forgotpassbtnlink_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles forgotpassbtnlink.LinkClicked
        Dim pass As New Changepassword
        switchpanel(pass)
    End Sub
End Class