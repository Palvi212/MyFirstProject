﻿Imports System.Data
Imports System.Data.OleDb
Public Class issuebookfrm
    Dim i As Integer
    Private Sub issuebooksearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuebooksearch.Click
        If isbookAlreadyIssue() = False Then
            MsgBox("Book Already Issued")
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select*from bookinfo where AccessionNo='" & TextBox1.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox1.Text = rdr.Item("AccessionNo")
                TextBox2.Text = rdr.Item("BookTitle")
                TextBox3.Text = rdr.Item("BookAuthor")
            Else
                MessageBox.Show("Record not Found")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox1.Focus()
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub
    'to check whether book already issued or not
    Private Function isbookAlreadyIssue()
        openconn()
        cmd = New OleDbCommand("select AccessionNo from issuebook where AccessionNo=@AccessionNo", conn)
        cmd.Parameters.AddWithValue("@AccessionNo", TextBox1.Text)
        rdr = cmd.ExecuteReader()
        While rdr.Read
            TextBox1.Clear()
            TextBox1.Focus()
            conn.Close()
            Return False
        End While
        Return True
    End Function
    Private Sub issueStaffsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issueStaffsearch.Click
        Try
            openconn()
            cmd = New OleDbCommand("select*from stuinfo where Studentid='" & TextBox4.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox4.Text = rdr.Item("Studentid")
                TextBox5.Text = rdr.Item("Studentname")
                TextBox6.Text = rdr.Item("Department")
            Else
                MessageBox.Show("Record not Found")
                TextBox4.Clear()
                TextBox5.Clear()
                TextBox6.Clear()
                TextBox4.Focus()
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub

    Private Sub Issuebtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Issuebtn.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox1.Text = "" Then
            MessageBox.Show("Please Fill All Details,Before Proceed")
            TextBox1.Focus()
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("insert into issuebook([AccessionNo],[BookTitle],[Author],[idRollno],[SName],[Department],[Type],[issueDate],[returnDate])" + "values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & ComboBox1.Text & "','" & issuedate.Text & "','" & returndate.Text & "')", conn)
            cmd.ExecuteNonQuery()
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            MessageBox.Show("Book Issued Successfully", "Issue Book")
            clr()
            TextBox1.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Book Not Issued,Error!")
            conn.Close()
        End Try
    End Sub

    Private Sub issuerefreshBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuerefreshBtn.Click
        clr()
    End Sub

    Private Sub backbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles backbtn.Click
        mainpage.Show()
        Me.Hide()
    End Sub


    'function clr
    Private Sub clr()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        ComboBox1.Text = ""
        issuedate.Text = ""
        returndate.Text = ""
    End Sub
    'showing data into grid
    Private Sub gridview()
        openconn()
        Dim sql As String = "select * from bookinfo"
        da = New OleDbDataAdapter(sql, conn)
        ds = New DataSet
        da.Fill(ds, "bookinfo")
        DataGridView1.DataSource = ds.Tables("bookinfo")
        conn.Close()
    End Sub
    Private Sub issuebookfrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        gridview()
    End Sub

    Private Sub searchbookbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchbookbtn.Click
        If TextBox7.Text = "" Then
            MsgBox("Enter Book AccessionNo")
            TextBox1.Focus()
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select * from bookinfo where AccessionNo='" & TextBox7.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox7.Text = rdr.Item("AccessionNo")
            Else
                MessageBox.Show("Book not Found")
                TextBox7.Focus()
                Exit Sub
            End If
            cmd = New OleDbCommand("select * from bookinfo where AccessionNo='" & TextBox7.Text & "'", conn)
            da = New OleDbDataAdapter(cmd)
            ds = New DataSet
            da.Fill(ds, "bookinfo")
            DataGridView1.DataSource = ds.Tables("bookinfo")
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            i = DataGridView1.CurrentRow.Index
            TextBox1.Text = DataGridView1.Item(0, i).Value
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub
End Class