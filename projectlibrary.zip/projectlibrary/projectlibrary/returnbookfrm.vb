﻿Imports System.Data.OleDb
Public Class returnbookfrm
    Dim i As Integer
    Private Sub gridview()
        openconn()
        cmd = New OleDbCommand("select * from issuebook", conn)
        da = New OleDbDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "issuebook")
        DataGridView1.DataSource = ds.Tables("issuebook")
        conn.Close()
    End Sub
    Private Sub returnbooksearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles returnbooksearch.Click
        If TextBox1.Text = "" Then
            MsgBox("Enter AccessionNo.", MsgBoxStyle.Information)
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select*from issuebook where AccessionNo='" & TextBox1.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox1.Text = rdr.Item("AccessionNo")
                TextBox2.Text = rdr.Item("BookTitle")
                TextBox4.Text = rdr.Item("idRollno")
                issuedate.Text = rdr.Item("issueDate")
                returndate.Text = rdr.Item("returnDate")
                ComboBox1.Text = rdr.Item("Type")
                fine()
            Else
                MessageBox.Show("Record not Found")
                Exit Sub
            End If
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Returnbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Returnbtn.Click
        If TextBox1.Text = "" Then
            MsgBox("Enter the detail,before procced", MsgBoxStyle.Information)
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select*from issuebook where AccessionNo='" & TextBox1.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox1.Text = rdr.Item("AccessionNo")
            Else
                MessageBox.Show("Record not Found")
                Exit Sub
            End If
            cmd = New OleDbCommand("delete * from issuebook where AccessionNo='" & TextBox1.Text & "'", conn)
            cmd.ExecuteNonQuery()
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
            conn.Close()
        End Try
        Try
            openconn()
            cmd = New OleDbCommand("insert into returnbook([AccessionNo],[BookTitle],[idRollno],[Type],[issueDate],[returnDate],[todayDate],[delay],[fine])" + "values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox4.Text & "','" & ComboBox1.Text & "','" & issuedate.Text & "','" & returndate.Text & "','" & todaydate.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "')", conn)
            cmd.ExecuteNonQuery()
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            MessageBox.Show("Book Returned Successfully", "Return Book")
            clr()
            gridview()
            TextBox1.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
    'calculate fine
    Private Sub fine()
        Dim diffdate As String
        diffdate = DateDiff(DateInterval.Day, returndate.Value.Date, todaydate.Value.Date)
        TextBox8.Text = diffdate
        diffdate *= 10
        TextBox9.Text = diffdate
    End Sub

    Private Sub issuerefreshBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuerefreshBtn.Click
        clr()
        gridview()
    End Sub

    Private Sub backbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles backbtn.Click
        mainpage.Show()
        Me.Hide()
    End Sub

    Private Sub returnbookfrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LbdatabaseDataSet4.issuebook' table. You can move, or remove it, as needed.
        Me.IssuebookTableAdapter.Fill(Me.LbdatabaseDataSet4.issuebook)
        gridview()
    End Sub
    Private Sub clr()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox4.Clear()
        ComboBox1.Text = ""
        issuedate.Clear()
        returndate.Text = ""
        todaydate.Text = ""
        TextBox8.Clear()
        TextBox9.Clear()
    End Sub

    Private Sub search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles search.Click
        If TextBox3.Text = "" Then
            MsgBox("Enter Book AccessionNo")
            TextBox3.Focus()
            Exit Sub
        End If
        Try
            openconn()
            cmd = New OleDbCommand("select * from issuebook where AccessionNo='" & TextBox3.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox3.Text = rdr.Item("AccessionNo")
            Else
                MessageBox.Show("Book not Found")
                TextBox3.Focus()
                Exit Sub
            End If
            cmd = New OleDbCommand("select * from issuebook where AccessionNo='" & TextBox3.Text & "'", conn)
            da = New OleDbDataAdapter(cmd)
            ds = New DataSet
            da.Fill(ds, "issuebook")
            DataGridView1.DataSource = ds.Tables("issuebook")
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            i = DataGridView1.CurrentRow.Index
            TextBox1.Text = DataGridView1.Item(0, i).Value
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub
End Class