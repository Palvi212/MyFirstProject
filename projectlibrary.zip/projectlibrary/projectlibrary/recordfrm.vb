﻿Public Class recordfrm
    Private Sub Staffrecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Staffrecord.Click
        Dim staffinfo As New staffinfofrm
        switchpanel(staffinfo)
    End Sub

    Private Sub Sturecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Sturecord.Click
        Dim stuinfo As New stuinfofrm
        switchpanel(stuinfo)
    End Sub

    Private Sub Bookrecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bookrecord.Click
        Dim bookrec As New searchbookfrm
        bookrec.TopLevel = False
        Panel2.Controls.Add(bookrec)
        bookrec.Visible = True
        bookrec.WindowState = FormWindowState.Maximized
        bookrec.FormBorderStyle = Windows.Forms.FormBorderStyle.None
    End Sub

    Private Sub issuedbookrecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuedbookrecord.Click
        Dim issuedinfo As New issuedbookdetail
        switchpanel(issuedinfo)
    End Sub

    Private Sub returnedrecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles returnedrecord.Click
        Dim returnedinfo As New returnedbookdetail
        switchpanel(returnedinfo)
    End Sub

    Private Sub switchpanel(ByVal panel As UserControl)
        Panel2.Controls.Clear()
        panel.Top = False
        Panel2.Controls.Add(panel)
    End Sub
End Class