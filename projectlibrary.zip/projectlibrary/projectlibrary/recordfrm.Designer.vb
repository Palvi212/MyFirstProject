﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class recordfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(recordfrm))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.returnedrecord = New System.Windows.Forms.Button()
        Me.issuedbookrecord = New System.Windows.Forms.Button()
        Me.Bookrecord = New System.Windows.Forms.Button()
        Me.Sturecord = New System.Windows.Forms.Button()
        Me.Staffrecord = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.returnedrecord)
        Me.Panel1.Controls.Add(Me.issuedbookrecord)
        Me.Panel1.Controls.Add(Me.Bookrecord)
        Me.Panel1.Controls.Add(Me.Sturecord)
        Me.Panel1.Controls.Add(Me.Staffrecord)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(0, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(206, 464)
        Me.Panel1.TabIndex = 0
        '
        'returnedrecord
        '
        Me.returnedrecord.BackColor = System.Drawing.Color.LightSeaGreen
        Me.returnedrecord.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.returnedrecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.returnedrecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.returnedrecord.Location = New System.Drawing.Point(10, 325)
        Me.returnedrecord.Name = "returnedrecord"
        Me.returnedrecord.Size = New System.Drawing.Size(176, 46)
        Me.returnedrecord.TabIndex = 5
        Me.returnedrecord.Text = "Returned Book Record"
        Me.returnedrecord.UseVisualStyleBackColor = False
        '
        'issuedbookrecord
        '
        Me.issuedbookrecord.BackColor = System.Drawing.Color.LightSeaGreen
        Me.issuedbookrecord.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.issuedbookrecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.issuedbookrecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.issuedbookrecord.Location = New System.Drawing.Point(11, 261)
        Me.issuedbookrecord.Name = "issuedbookrecord"
        Me.issuedbookrecord.Size = New System.Drawing.Size(176, 41)
        Me.issuedbookrecord.TabIndex = 4
        Me.issuedbookrecord.Text = "Issued Book Record"
        Me.issuedbookrecord.UseVisualStyleBackColor = False
        '
        'Bookrecord
        '
        Me.Bookrecord.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Bookrecord.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Bookrecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bookrecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Bookrecord.Location = New System.Drawing.Point(11, 195)
        Me.Bookrecord.Name = "Bookrecord"
        Me.Bookrecord.Size = New System.Drawing.Size(176, 41)
        Me.Bookrecord.TabIndex = 3
        Me.Bookrecord.Text = "Book Record"
        Me.Bookrecord.UseVisualStyleBackColor = False
        '
        'Sturecord
        '
        Me.Sturecord.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Sturecord.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Sturecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sturecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Sturecord.Location = New System.Drawing.Point(11, 122)
        Me.Sturecord.Name = "Sturecord"
        Me.Sturecord.Size = New System.Drawing.Size(176, 41)
        Me.Sturecord.TabIndex = 2
        Me.Sturecord.Text = "Student Record"
        Me.Sturecord.UseVisualStyleBackColor = False
        '
        'Staffrecord
        '
        Me.Staffrecord.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Staffrecord.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Staffrecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Staffrecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Staffrecord.Location = New System.Drawing.Point(10, 54)
        Me.Staffrecord.Name = "Staffrecord"
        Me.Staffrecord.Size = New System.Drawing.Size(176, 41)
        Me.Staffrecord.TabIndex = 1
        Me.Staffrecord.Text = "Staff Record"
        Me.Staffrecord.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(-1, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(206, 40)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "View All Records"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Location = New System.Drawing.Point(203, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(793, 464)
        Me.Panel2.TabIndex = 1
        '
        'recordfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(996, 464)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "recordfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "All Records"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents returnedrecord As System.Windows.Forms.Button
    Friend WithEvents issuedbookrecord As System.Windows.Forms.Button
    Friend WithEvents Bookrecord As System.Windows.Forms.Button
    Friend WithEvents Sturecord As System.Windows.Forms.Button
    Friend WithEvents Staffrecord As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
