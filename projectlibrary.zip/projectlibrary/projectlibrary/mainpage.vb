﻿Public Class mainpage
    Private Sub managestudentbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managestudentbtn.Click
        managestudentfrm.ShowDialog()
    End Sub

    Private Sub managebookbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managebookbtn.Click
        managebookfrm.ShowDialog()
    End Sub

    Private Sub searchbookbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchbookbtn.Click
        searchbookfrm.ShowDialog()
    End Sub

    Private Sub issuebookbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuebookbtn.Click
        issuebookfrm.ShowDialog()
    End Sub

    Private Sub returnbookbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles returnbookbtn.Click
        returnbookfrm.ShowDialog()
    End Sub

    Private Sub viewrecordbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles viewrecordbtn.Click
        recordfrm.ShowDialog()
    End Sub

    Private Sub logoutbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles logoutbtn.Click
        Me.Close()
        loginform.Show()
    End Sub

    Private Sub managestffbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managestffbtn.Click
        managestafffrm.ShowDialog()
    End Sub
    Private Sub renewbookbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles renewbookbtn.Click
        renewbookfrm.ShowDialog()
    End Sub


    Private Sub mainpage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        Me.WindowState = FormWindowState.Maximized
    End Sub

    'menustrip
    Private Sub SettingsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsToolStripMenuItem.Click
        settingfrm.ShowDialog()
    End Sub

    Private Sub RecordsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RecordsToolStripMenuItem.Click
        recordfrm.ShowDialog()
    End Sub

    Private Sub IssueBookToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IssueBookToolStripMenuItem1.Click
        issuebookfrm.ShowDialog()
    End Sub

    Private Sub ReturnBookToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnBookToolStripMenuItem.Click
        returnbookfrm.ShowDialog()
    End Sub

    Private Sub ISSUEBOOKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ISSUEBOOKToolStripMenuItem.Click
        managestafffrm.ShowDialog()
    End Sub

    Private Sub StudentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StudentToolStripMenuItem.Click
        managestudentfrm.ShowDialog()
    End Sub

    Private Sub BookToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BookToolStripMenuItem.Click
        managebookfrm.ShowDialog()
    End Sub
    Private Sub LogoutInfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoutInfoToolStripMenuItem.Click
        Me.Close()
        loginform.Show()
    End Sub
    Private Sub BackupDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackupDataToolStripMenuItem.Click
        backup.ShowDialog()
    End Sub

    'effect
    Private Sub managestudentbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managestudentbtn.MouseHover
        managestudentbtn.BackColor = Color.Black
    End Sub

    Private Sub managestudentbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managestudentbtn.MouseLeave
        managestudentbtn.BackColor = Color.Teal
    End Sub

    Private Sub managestffbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managestffbtn.MouseHover
        managestffbtn.BackColor = Color.Black
    End Sub

    Private Sub managestffbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managestffbtn.MouseLeave
        managestffbtn.BackColor = Color.Teal
    End Sub

    Private Sub managebookbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managebookbtn.MouseHover
        managebookbtn.BackColor = Color.Black
    End Sub

    Private Sub managebookbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles managebookbtn.MouseLeave
        managebookbtn.BackColor = Color.Teal
    End Sub

    Private Sub searchbookbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchbookbtn.MouseHover
        searchbookbtn.BackColor = Color.Black
    End Sub

    Private Sub searchbookbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchbookbtn.MouseLeave
        searchbookbtn.BackColor = Color.Teal
    End Sub

    Private Sub issuebookbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuebookbtn.MouseHover
        issuebookbtn.BackColor = Color.Black
    End Sub

    Private Sub issuebookbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles issuebookbtn.MouseLeave
        issuebookbtn.BackColor = Color.Teal
    End Sub

    Private Sub returnbookbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles returnbookbtn.MouseHover
        returnbookbtn.BackColor = Color.Black
    End Sub

    Private Sub returnbookbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles returnbookbtn.MouseLeave
        returnbookbtn.BackColor = Color.Teal
    End Sub

    Private Sub viewrecordbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles viewrecordbtn.MouseHover
        viewrecordbtn.BackColor = Color.Black
    End Sub

    Private Sub viewrecordbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles viewrecordbtn.MouseLeave
        viewrecordbtn.BackColor = Color.Teal
    End Sub

    Private Sub logoutbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles logoutbtn.MouseHover
        logoutbtn.BackColor = Color.Black
    End Sub

    Private Sub logoutbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles logoutbtn.MouseLeave
        logoutbtn.BackColor = Color.Teal
    End Sub

    Private Sub renewbookbtn_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles renewbookbtn.MouseHover
        renewbookbtn.BackColor = Color.Black
    End Sub

    Private Sub renewbookbtn_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles renewbookbtn.MouseLeave
        renewbookbtn.BackColor = Color.Teal
    End Sub
End Class