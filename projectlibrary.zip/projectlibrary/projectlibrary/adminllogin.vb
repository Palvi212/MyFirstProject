﻿Imports System.Data.OleDb
Public Class adminllogin

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            openconn()
            cmd = New OleDbCommand("Select * from login where  Userid='" & TextBox1.Text & "' and Password='" & TextBox2.Text & "'", conn)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                TextBox1.Text = rdr.Item("Userid")
                TextBox2.Text = rdr.Item("Password")
                Adminform.Show()
                loginform.Hide()
                TextBox1.Clear()
                TextBox2.Clear()
            Else
                MessageBox.Show("incorrect Userid/password")
                TextBox1.Clear()
                TextBox2.Clear()
            End If
            conn.Close()
        Catch ex As Exception
            MsgBox("Error logging in,please try again", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
    End Sub
End Class
