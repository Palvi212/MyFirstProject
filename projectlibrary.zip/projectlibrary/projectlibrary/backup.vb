﻿Imports System.Data.OleDb
Imports System.IO
Public Class backup

    Private Sub savebackup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles savebackup.Click
        Try
            Dim backup As New FolderBrowserDialog
            If backup.ShowDialog() = vbOK Then
                File.Copy("C:\Users\admin\Documents\project\projectlibrary\lbdatabase.accdb", backup.SelectedPath & "\lbdatabase.accdb")
                MessageBox.Show("Backup Created Successfully")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub

    Private Sub restorebackupbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles restorebackupbtn.Click
        Try
            Dim backup As New FolderBrowserDialog
            If backup.ShowDialog() = vbOK Then
                File.Copy(backup.SelectedPath & "\lbdatabase.accdb", "C:\Users\admin\Documents\project\projectlibrary\lbdatabase.accdb")
                MessageBox.Show("Backup Restored Successfully")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try
    End Sub
End Class